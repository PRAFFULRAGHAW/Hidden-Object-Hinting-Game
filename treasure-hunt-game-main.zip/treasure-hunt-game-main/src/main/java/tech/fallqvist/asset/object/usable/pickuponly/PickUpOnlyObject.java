package tech.fallqvist.asset.object.usable.pickuponly;

import tech.fallqvist.GamePanel;
import tech.fallqvist.asset.object.Object;

public class PickUpOnlyObject extends Object {

    public PickUpOnlyObject(GamePanel gamePanel) {
        super(gamePanel);
    }
}
