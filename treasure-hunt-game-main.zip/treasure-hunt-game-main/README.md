# Blue boy 2D Game
###### Developer: Patrik Fallqvist Magnusson

Simple 2D swing game demo project following the [fenomenal tutorial series](https://youtube.com/playlist?list=PL_QPQmz5C6WUF-pOQDsbsKbaBZqXj4qSq)
 made by [RyiSnow](https://www.youtube.com/c/RyiSnow). Go subscribe to him, you won't regret it!
 
 This has been my, still ongoing, summer project and I'm hoping to continue expand the engine and make it into a proper RPG Zelda/Pokemon style 2D game in the future.
